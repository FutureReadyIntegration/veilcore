# Veil OS - Ubuntu Installation Guide

Complete installation guide for deploying Veil OS Hospital Security System on Ubuntu Linux.

---

## 🔱 Table of Contents

1. [System Requirements](#system-requirements)
2. [Quick Install](#quick-install)
3. [Manual Installation](#manual-installation)
4. [Configuration](#configuration)
5. [Starting Services](#starting-services)
6. [Accessing Dashboard](#accessing-dashboard)
7. [Troubleshooting](#troubleshooting)
8. [Uninstallation](#uninstallation)

---

## System Requirements

### Minimum Requirements
- **OS**: Ubuntu 20.04 LTS or newer
- **CPU**: 2 cores
- **RAM**: 4 GB
- **Disk**: 10 GB free space
- **Network**: Internet connection (for installation)

### Recommended Requirements
- **OS**: Ubuntu 22.04 LTS or Ubuntu 24.04 LTS
- **CPU**: 4+ cores
- **RAM**: 8+ GB
- **Disk**: 20+ GB SSD
- **Network**: 1 Gbps connection

### Software Requirements
The installer will automatically install these, but for reference:
- Python 3.8+
- Node.js 18+
- npm 9+
- systemd

---

## Quick Install

### One-Command Installation

```bash
# Clone the repository
git clone https://github.com/FutureReadyIntegration/VeilUnleashed.git
cd VeilUnleashed

# Make installer executable
chmod +x install-ubuntu.sh

# Run installer (requires sudo)
sudo ./install-ubuntu.sh
```

The installer will:
1. ✅ Update system packages
2. ✅ Install dependencies (Python, Node.js, system tools)
3. ✅ Create `veil` system user
4. ✅ Install Veil OS to `/opt/veil_os`
5. ✅ Set up Python virtual environment
6. ✅ Install Python packages
7. ✅ Build frontend dashboard
8. ✅ Create systemd services
9. ✅ Configure firewall

**Installation time**: 5-10 minutes (depending on internet speed)

---

## Manual Installation

If you prefer manual installation or need custom setup:

### Step 1: Update System

```bash
sudo apt update
sudo apt upgrade -y
```

### Step 2: Install System Dependencies

```bash
sudo apt install -y \
    python3 \
    python3-pip \
    python3-venv \
    python3-dev \
    nodejs \
    npm \
    build-essential \
    git \
    curl \
    systemd
```

### Step 3: Install Node.js 18+

```bash
# Add NodeSource repository
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -

# Install Node.js
sudo apt install -y nodejs

# Verify versions
node --version  # Should be v18.x or higher
npm --version   # Should be v9.x or higher
```

### Step 4: Create System User

```bash
# Create veil system user
sudo useradd -r -s /bin/bash -d /opt/veil_os -m veil
```

### Step 5: Clone and Install Veil OS

```bash
# Clone repository
git clone https://github.com/FutureReadyIntegration/VeilUnleashed.git
cd VeilUnleashed

# Copy to installation directory
sudo cp -r veil_os/* /opt/veil_os/

# Set ownership
sudo chown -R veil:veil /opt/veil_os
```

### Step 6: Install Python Dependencies

```bash
# Create virtual environment
sudo -u veil python3 -m venv /opt/veil_os/venv

# Activate virtual environment
sudo -u veil /opt/veil_os/venv/bin/pip install --upgrade pip

# Install requirements
sudo -u veil /opt/veil_os/venv/bin/pip install -r requirements.txt
```

### Step 7: Build Frontend Dashboard

```bash
cd /opt/veil_os/cockpit-frontend

# Copy configuration files
sudo cp /path/to/VeilUnleashed/package.json .
sudo cp /path/to/VeilUnleashed/vite.config.js .

# Install dependencies
sudo -u veil npm install

# Build production bundle
sudo -u veil npm run build
```

### Step 8: Create Systemd Service

```bash
sudo nano /etc/systemd/system/veil-dashboard.service
```

Paste the following:

```ini
[Unit]
Description=Veil OS Dashboard Service
After=network.target
Wants=network-online.target

[Service]
Type=simple
User=veil
Group=veil
WorkingDirectory=/opt/veil_os
Environment="PATH=/opt/veil_os/venv/bin:/usr/local/bin:/usr/bin:/bin"
ExecStart=/opt/veil_os/venv/bin/python3 /opt/veil_os/veil_gui.py
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=veil-dashboard

# Security settings
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/opt/veil_os

[Install]
WantedBy=multi-user.target
```

### Step 9: Enable and Start Service

```bash
# Reload systemd
sudo systemctl daemon-reload

# Enable service (start on boot)
sudo systemctl enable veil-dashboard

# Start service
sudo systemctl start veil-dashboard
```

---

## Configuration

### Environment Variables

Create `/opt/veil_os/.env` for custom configuration:

```bash
# Dashboard Configuration
VEIL_HOST=0.0.0.0
VEIL_PORT=8000
VEIL_LOG_LEVEL=INFO

# Security Settings
VEIL_SECRET_KEY=your-secret-key-here
VEIL_ALLOWED_ORIGINS=http://localhost:3000,http://localhost:8000

# Database (if using)
VEIL_DB_PATH=/opt/veil_os/data/veil.db
```

### Firewall Configuration

```bash
# Allow dashboard access
sudo ufw allow 8000/tcp comment 'Veil Dashboard'

# Allow frontend (if separate server)
sudo ufw allow 3000/tcp comment 'Veil Frontend'

# Enable firewall
sudo ufw enable
```

---

## Starting Services

### Start Dashboard

```bash
sudo systemctl start veil-dashboard
```

### Check Status

```bash
sudo systemctl status veil-dashboard
```

### View Logs

```bash
# Real-time logs
sudo journalctl -u veil-dashboard -f

# Last 100 lines
sudo journalctl -u veil-dashboard -n 100

# Since boot
sudo journalctl -u veil-dashboard -b
```

### Restart Service

```bash
sudo systemctl restart veil-dashboard
```

### Stop Service

```bash
sudo systemctl stop veil-dashboard
```

---

## Accessing Dashboard

### Local Access

```bash
http://localhost:8000
```

### Network Access

```bash
# Find your server IP
hostname -I

# Access from browser
http://YOUR_SERVER_IP:8000
```

### Default Features

- **Command Center**: Live organ status and metrics
- **3D Threat Visualization**: Real-time network topology
- **Security Feed**: Event monitoring
- **Organ Management**: Start/stop security modules
- **Theme Toggle**: Clinical (light) and Cyber (dark) modes

---

## Troubleshooting

### Service Won't Start

```bash
# Check logs for errors
sudo journalctl -u veil-dashboard -n 50

# Check if port is already in use
sudo netstat -tlnp | grep 8000

# Verify Python dependencies
sudo -u veil /opt/veil_os/venv/bin/pip list
```

### Port Already in Use

```bash
# Find process using port 8000
sudo lsof -i :8000

# Kill process (if safe)
sudo kill -9 PID
```

### Permission Errors

```bash
# Fix ownership
sudo chown -R veil:veil /opt/veil_os

# Fix permissions
sudo chmod -R 755 /opt/veil_os
```

### Frontend Not Loading

```bash
# Rebuild frontend
cd /opt/veil_os/cockpit-frontend
sudo -u veil npm run build

# Check static files
ls -la /opt/veil_os/cockpit-frontend/dist
```

### Python Import Errors

```bash
# Reinstall requirements
sudo -u veil /opt/veil_os/venv/bin/pip install -r /opt/veil_os/requirements.txt --force-reinstall
```

### Check Organ Status

```bash
# List all organs
ls /opt/veil_os/organs/

# Check specific organ
cat /opt/veil_os/organs/guardian/guardian.py
```

---

## Uninstallation

### Remove Veil OS

```bash
# Stop service
sudo systemctl stop veil-dashboard
sudo systemctl disable veil-dashboard

# Remove service file
sudo rm /etc/systemd/system/veil-dashboard.service
sudo systemctl daemon-reload

# Remove installation directory
sudo rm -rf /opt/veil_os

# Remove user (optional)
sudo userdel -r veil

# Remove firewall rules (optional)
sudo ufw delete allow 8000/tcp
sudo ufw delete allow 3000/tcp
```

---

## Additional Information

### File Locations

```
/opt/veil_os/              # Main installation directory
├── veil_gui.py            # Main dashboard server
├── venv/                  # Python virtual environment
├── organs/                # Security organ modules
├── cockpit-frontend/      # Web dashboard
│   ├── src/              # React source files
│   ├── dist/             # Built production files
│   └── index.html        # Main HTML file
├── ledger.json            # Security event ledger
├── logs/                  # Log files
└── data/                  # Application data
```

### Service Management

```bash
# Auto-start on boot
sudo systemctl enable veil-dashboard

# Prevent auto-start
sudo systemctl disable veil-dashboard

# Check if enabled
sudo systemctl is-enabled veil-dashboard

# View service configuration
sudo systemctl cat veil-dashboard
```

### Performance Tuning

For production deployments:

```bash
# Increase file descriptors
sudo nano /etc/security/limits.conf
# Add: veil soft nofile 65536
# Add: veil hard nofile 65536

# Increase systemd limits
sudo nano /etc/systemd/system/veil-dashboard.service
# Add under [Service]:
# LimitNOFILE=65536
```

---

## Support

For issues, questions, or contributions:

- **GitHub**: https://github.com/FutureReadyIntegration/VeilUnleashed
- **Issues**: https://github.com/FutureReadyIntegration/VeilUnleashed/issues

---

## License

MIT License - See LICENSE file for details

---

**🛡️ Veil OS - Protecting Hospital Infrastructure Since 2024 🛡️**
