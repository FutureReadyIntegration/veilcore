#!/bin/bash
################################################################################
# Veil OS - Ubuntu/Linux Installation Script
# 
# Description: One-command installer for Veil OS Hospital Security System
# Usage: sudo ./install-ubuntu.sh
# Requirements: Ubuntu 20.04 LTS or newer
################################################################################

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Installation paths
INSTALL_DIR="/opt/veil_os"
SERVICE_USER="veil"
VENV_DIR="${INSTALL_DIR}/venv"
FRONTEND_DIR="${INSTALL_DIR}/cockpit-frontend"

echo -e "${CYAN}"
echo "╔═══════════════════════════════════════════════════════════╗"
echo "║                                                           ║"
echo "║              🔱 VEIL OS INSTALLATION 🔱                   ║"
echo "║                                                           ║"
echo "║          Hospital Security Defense System                 ║"
echo "║                                                           ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   echo -e "${RED}✗ This script must be run as root${NC}"
   echo "  Usage: sudo ./install-ubuntu.sh"
   exit 1
fi

echo -e "${GREEN}✓ Running as root${NC}"

# Detect Ubuntu version
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$NAME
    VER=$VERSION_ID
    echo -e "${GREEN}✓ Detected: ${OS} ${VER}${NC}"
else
    echo -e "${RED}✗ Cannot detect OS version${NC}"
    exit 1
fi

# Check Ubuntu version
if [[ "$ID" != "ubuntu" ]] || [[ "${VER}" < "20.04" ]]; then
    echo -e "${YELLOW}⚠ Warning: Veil OS is tested on Ubuntu 20.04+${NC}"
    echo -e "${YELLOW}  Your version: ${OS} ${VER}${NC}"
    read -p "Continue anyway? (y/N) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# ============================================
# STEP 1: Update System
# ============================================
echo ""
echo -e "${CYAN}[1/8] Updating system packages...${NC}"
apt update -qq
apt upgrade -y -qq
echo -e "${GREEN}✓ System updated${NC}"

# ============================================
# STEP 2: Install System Dependencies
# ============================================
echo ""
echo -e "${CYAN}[2/8] Installing system dependencies...${NC}"
apt install -y \
    python3 \
    python3-pip \
    python3-venv \
    python3-dev \
    nodejs \
    npm \
    build-essential \
    git \
    curl \
    wget \
    systemd \
    ufw \
    nano \
    htop \
    net-tools

echo -e "${GREEN}✓ System dependencies installed${NC}"

# Verify Node.js version
NODE_VERSION=$(node --version | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo -e "${YELLOW}⚠ Node.js version is ${NODE_VERSION}, upgrading to v18+...${NC}"
    curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
    apt install -y nodejs
fi

echo -e "${GREEN}✓ Node.js $(node --version)${NC}"
echo -e "${GREEN}✓ Python $(python3 --version)${NC}"

# ============================================
# STEP 3: Create Veil User
# ============================================
echo ""
echo -e "${CYAN}[3/8] Creating veil system user...${NC}"
if id "$SERVICE_USER" &>/dev/null; then
    echo -e "${YELLOW}⚠ User 'veil' already exists${NC}"
else
    useradd -r -s /bin/bash -d "$INSTALL_DIR" -m "$SERVICE_USER"
    echo -e "${GREEN}✓ User 'veil' created${NC}"
fi

# ============================================
# STEP 4: Copy Veil OS Files
# ============================================
echo ""
echo -e "${CYAN}[4/8] Installing Veil OS to ${INSTALL_DIR}...${NC}"

# Create installation directory if it doesn't exist
mkdir -p "$INSTALL_DIR"

# Copy veil_os directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -d "${SCRIPT_DIR}/veil_os" ]; then
    echo "  Copying veil_os files..."
    cp -r "${SCRIPT_DIR}/veil_os/"* "$INSTALL_DIR/"
    echo -e "${GREEN}✓ Veil OS files copied${NC}"
else
    echo -e "${RED}✗ veil_os directory not found!${NC}"
    echo "  Expected: ${SCRIPT_DIR}/veil_os"
    exit 1
fi

# Set ownership
chown -R ${SERVICE_USER}:${SERVICE_USER} "$INSTALL_DIR"
echo -e "${GREEN}✓ Ownership set to ${SERVICE_USER}${NC}"

# ============================================
# STEP 5: Install Python Dependencies
# ============================================
echo ""
echo -e "${CYAN}[5/8] Installing Python dependencies...${NC}"

# Create virtual environment
sudo -u ${SERVICE_USER} python3 -m venv "$VENV_DIR"
echo -e "${GREEN}✓ Python virtual environment created${NC}"

# Upgrade pip
sudo -u ${SERVICE_USER} "${VENV_DIR}/bin/pip" install --upgrade pip setuptools wheel

# Install requirements
if [ -f "${INSTALL_DIR}/requirements.txt" ]; then
    sudo -u ${SERVICE_USER} "${VENV_DIR}/bin/pip" install -r "${INSTALL_DIR}/requirements.txt"
    echo -e "${GREEN}✓ Python packages installed${NC}"
elif [ -f "${SCRIPT_DIR}/requirements.txt" ]; then
    sudo -u ${SERVICE_USER} "${VENV_DIR}/bin/pip" install -r "${SCRIPT_DIR}/requirements.txt"
    echo -e "${GREEN}✓ Python packages installed${NC}"
else
    echo -e "${YELLOW}⚠ requirements.txt not found, installing core packages...${NC}"
    sudo -u ${SERVICE_USER} "${VENV_DIR}/bin/pip" install fastapi uvicorn[standard] psutil pyyaml
fi

# ============================================
# STEP 6: Install Frontend Dependencies
# ============================================
echo ""
echo -e "${CYAN}[6/8] Installing frontend dependencies...${NC}"

if [ -d "${FRONTEND_DIR}" ]; then
    cd "${FRONTEND_DIR}"
    
    # Copy package.json if it doesn't exist
    if [ ! -f "package.json" ] && [ -f "${SCRIPT_DIR}/package.json" ]; then
        cp "${SCRIPT_DIR}/package.json" .
    fi
    
    # Copy vite.config.js if it doesn't exist
    if [ ! -f "vite.config.js" ] && [ -f "${SCRIPT_DIR}/vite.config.js" ]; then
        cp "${SCRIPT_DIR}/vite.config.js" .
    fi
    
    if [ -f "package.json" ]; then
        sudo -u ${SERVICE_USER} npm install
        sudo -u ${SERVICE_USER} npm run build
        echo -e "${GREEN}✓ Frontend built successfully${NC}"
    else
        echo -e "${YELLOW}⚠ package.json not found in ${FRONTEND_DIR}${NC}"
    fi
else
    echo -e "${YELLOW}⚠ cockpit-frontend directory not found${NC}"
fi

cd "$INSTALL_DIR"

# ============================================
# STEP 7: Install Systemd Services
# ============================================
echo ""
echo -e "${CYAN}[7/8] Installing systemd services...${NC}"

# Create veil-dashboard service
cat > /etc/systemd/system/veil-dashboard.service << EOF
[Unit]
Description=Veil OS Dashboard Service
After=network.target
Wants=network-online.target

[Service]
Type=simple
User=${SERVICE_USER}
Group=${SERVICE_USER}
WorkingDirectory=${INSTALL_DIR}
Environment="PATH=${VENV_DIR}/bin:/usr/local/bin:/usr/bin:/bin"
ExecStart=${VENV_DIR}/bin/python3 ${INSTALL_DIR}/veil_gui.py
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=veil-dashboard

# Security settings
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=${INSTALL_DIR}

[Install]
WantedBy=multi-user.target
EOF

echo -e "${GREEN}✓ veil-dashboard.service created${NC}"

# Reload systemd
systemctl daemon-reload

# Enable services
systemctl enable veil-dashboard.service
echo -e "${GREEN}✓ Services enabled${NC}"

# ============================================
# STEP 8: Configure Firewall
# ============================================
echo ""
echo -e "${CYAN}[8/8] Configuring firewall...${NC}"

# Allow SSH
ufw allow 22/tcp comment 'SSH'

# Allow dashboard
ufw allow 8000/tcp comment 'Veil Dashboard'

# Allow frontend (if separate)
ufw allow 3000/tcp comment 'Veil Frontend'

# Enable firewall (if not already enabled)
ufw --force enable || true

echo -e "${GREEN}✓ Firewall configured${NC}"

# ============================================
# INSTALLATION COMPLETE
# ============================================
echo ""
echo -e "${GREEN}"
echo "╔═══════════════════════════════════════════════════════════╗"
echo "║                                                           ║"
echo "║          ✓ VEIL OS INSTALLATION COMPLETE ✓               ║"
echo "║                                                           ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo -e "${NC}"

echo ""
echo -e "${CYAN}Next Steps:${NC}"
echo ""
echo -e "${YELLOW}1. Start Veil OS Dashboard:${NC}"
echo "   sudo systemctl start veil-dashboard"
echo ""
echo -e "${YELLOW}2. Check service status:${NC}"
echo "   sudo systemctl status veil-dashboard"
echo ""
echo -e "${YELLOW}3. View logs:${NC}"
echo "   sudo journalctl -u veil-dashboard -f"
echo ""
echo -e "${YELLOW}4. Access Dashboard:${NC}"
echo "   http://$(hostname -I | awk '{print $1}'):8000"
echo "   http://localhost:8000"
echo ""
echo -e "${CYAN}Useful Commands:${NC}"
echo "  Stop:    sudo systemctl stop veil-dashboard"
echo "  Restart: sudo systemctl restart veil-dashboard"
echo "  Disable: sudo systemctl disable veil-dashboard"
echo ""
echo -e "${GREEN}🛡️  Veil OS is ready to protect your hospital! 🛡️${NC}"
echo ""
